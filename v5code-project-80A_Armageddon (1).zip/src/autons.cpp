#include "vex.h"

motor_group leftDrive = motor_group(leftDriveA, leftDriveB, leftMotorC);


motor_group rightDrive = motor_group(rightMotorA, rightMotorB, rightMotorC);

void default_constants(){
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);
  chassis.set_drive_exit_conditions(1.5, 300, 5000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

void odom_constants(){
  default_constants();
  chassis.drive_max_voltage = 8;
  chassis.drive_settle_error = 3;
}

void drive_test(){
  chassis.drive_distance(6);
  chassis.drive_distance(12);
  chassis.drive_distance(18);
  chassis.drive_distance(-36);
}

void turn_test(){
  chassis.turn_to_angle(5);
  chassis.turn_to_angle(30);
  chassis.turn_to_angle(90);
  chassis.turn_to_angle(225);
  chassis.turn_to_angle(0);
}

void swing_test(){
  chassis.left_swing_to_angle(90);
  chassis.right_swing_to_angle(0);
}

void full_test(){
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-36);
  chassis.right_swing_to_angle(-90);
  chassis.drive_distance(24);
  chassis.turn_to_angle(0);
}

void odom_test(){
  chassis.set_coordinates(0, 0, 0);
  while(1){
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(0,50, "X: %f", chassis.get_X_position());
    Brain.Screen.printAt(0,70, "Y: %f", chassis.get_Y_position());
    Brain.Screen.printAt(0,90, "Heading: %f", chassis.get_absolute_heading());
    Brain.Screen.printAt(0,110, "ForwardTracker: %f", chassis.get_ForwardTracker_position());
    Brain.Screen.printAt(0,130, "SidewaysTracker: %f", chassis.get_SidewaysTracker_position());
    task::sleep(20);
  }
}

void tank_odom_test(){
  odom_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.turn_to_point(24, 24);
  chassis.drive_to_point(24,24);
  chassis.drive_to_point(0,0);
  chassis.turn_to_angle(0);
}

void holonomic_odom_test(){
  odom_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.holonomic_drive_to_point(0, 18, 90);
  chassis.holonomic_drive_to_point(18, 0, 180);
  chassis.holonomic_drive_to_point(0, 18, 270);
  chassis.holonomic_drive_to_point(0, 0, 0);
}

void NearSideQuals() {
  Intake.setVelocity(100, percent);

  VertRight = true;

  Intake.spin(reverse);
  chassis.turn_to_angle(-35);
  Intake.stop();

  VertRight = false;
  chassis.turn_to_angle(-60);// change back to -80 in case
  chassis.turn_to_angle(0);
  chassis.drive_distance(8);// Change to 9 in case of contact with pvc pipe
  chassis.turn_to_angle(-45);
  Intake.spin(reverse);
  chassis.drive_distance(31);// Potentially increase drive distance

}

void SixBall() {
  leftDrive.setVelocity(100, percent); // Sets Drive Velocity
  rightDrive.setVelocity(100, percent);
  

  Intake.setVelocity(100, percent); // Sets Intake Velocity

  Intake.spin(forward); // Intakes First Triball Under Elevation Bar
  chassis.drive_distance(3);

  //Intake.stop();
  chassis.drive_timeout = 850;
  chassis.drive_distance(-32); // Drives reverse towards the goal

  chassis.turn_timeout = 350;
  chassis.turn_to_angle(-45); // Aligns itself with Matchload bar
  VertLeft = true;
  chassis.drive_distance(-16);
  
  VertLeft = false;
  chassis.drive_timeout = 250;
  chassis.drive_distance(3);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(-90);
  //VertRight = true;
  chassis.drive_timeout = 700; // was 720
  chassis.drive_distance(-15);
  
  //VertRight = false;

  chassis.drive_distance(14);
  chassis.turn_timeout = 500;
  chassis.turn_to_angle(90);
  Intake.spin(reverse);
  chassis.drive_timeout = 720;
  chassis.drive_distance(15);
  chassis.drive_distance(-12);
  
  //chassis.turn_to_angle(108); // Turns so that intake is facing towards the goal

  //chassis.drive_distance(14); // Pushes both Alliance triball and Triball that was under the bar
  //chassis.drive_distance(-8); // Drives back

  chassis.turn_timeout = 500;
  chassis.turn_to_angle(23); // Turns to align itself with the left-most triball placed near the barrier
  Intake.spin(forward); // Intakes the Triball
  chassis.drive_timeout = 1000;
  chassis.drive_distance(40);
  chassis.drive_distance(10);
  Intake.stop();

  chassis.turn_to_angle(160); // Turns to face the goal CHANGE TO 170 IF NEEDED
  chassis.drive_timeout = 500;
  chassis.drive_distance(17); //SUGEST HASHING OUT
  Intake.spinFor(reverse, 850, degrees); // Outtakes the 3rd triball
  chassis.turn_to_angle(47); // Aligns with Center triball near the barrier
  Intake.spin(forward); // Intakes the Triball
  chassis.drive_distance(28);
  wait(0.05, sec);
  chassis.drive_distance(4);//CHANGE TO 8 
  chassis.swing_timeout = 300;
  chassis.right_swing_to_angle(0);
  chassis.drive_timeout = 250;
  chassis.drive_distance(-5);
  //Intake.stop();
  //chassis.turn_timeout = 850;
  chassis.turn_to_angle(179); // Faces the goal
  Wings = true; // Uses Wings to push the triballs in at once
  Intake.spin(reverse);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);
  Wings = false;



}


void FourBall() {

  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  Intake.setVelocity(100, percent);

  chassis.drive_distance(40);
  chassis.turn_to_angle(60);
  Intake.spinFor(reverse, 720, degrees);
  chassis.drive_distance(-2);
  Intake.stop();
  //Intake.setVelocity(100, percent);
  chassis.turn_to_angle(-115);
  Intake.spin(forward);
  chassis.drive_distance(22);
  wait(0.1, seconds);
  Intake.stop();
  chassis.turn_to_angle(60);
  //Intake.setVelocity(50, percent);
  chassis.drive_distance(10);
  Intake.spinFor(reverse, 360, degrees);
  chassis.turn_to_angle(-55);
  
  Intake.spin(forward);
  chassis.drive_distance(15);
  Intake.stop();
  chassis.turn_to_angle(70);

  Wings = true;

  Intake.spin(reverse);
  chassis.drive_distance(30);
  Wings = false;

}

void ProgSkillsOver() {
  Lift.setVelocity(100, percent);
  Puncher.setVelocity(50, percent);
  Lift.setStopping(hold);
  Puncher.setStopping(hold);
  Intake.setVelocity(90, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);

  
  chassis.drive_distance(-15); 
  chassis.turn_to_angle(-60);
  chassis.drive_distance(-1);
  VertRight = true;
  Puncher.spin(forward);
  Lift.spinFor(forward, 250, degrees);
  wait(29, seconds);
  VertRight = false;
  Lift.spinFor(reverse, 250, degrees);
  Puncher.stop();
  chassis.turn_timeout = 500;
  chassis.turn_to_angle(45);
  chassis.drive_distance(-12);
  chassis.drive_distance(13);
  //chassis.turn_timeout = 1000;
  chassis.turn_to_angle(-70);
  chassis.drive_distance(25);
  chassis.turn_to_angle(-130);
  //Wings = true;
  Intake.spin(reverse);
  chassis.drive_distance(30); // Ba Ba Booey
  //Wings = false;
  chassis.turn_to_angle(-45);
  //leftDrive.setVelocity(100, percent);
  //rightDrive.setVelocity(100, percent);
  //chassis.drive_distance(-5);
  //chassis.turn_to_angle(-135);
  //Intake.stop();
  //chassis.drive_distance(20);
  //chassis.drive_distance(-5);
  //chassis.turn_to_angle(-45);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  Intake.spin(reverse);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(22); // Initial Push to push triballs over barrier
  chassis.drive_timeout = 850;
  chassis.drive_distance(-15);
  Intake.stop();

  Wings = true;
  //leftDrive.spin(fwd, 12, volt); // Working Code
  //rightDrive.spin(fwd, 12, volt);
  //wait(1.5, sec);
  
  leftDrive.spin(fwd, 12, volt); // New Code Test
  rightDrive.spin(fwd, 12, volt);
  wait(1.8, sec);

  Wings = false;

  chassis.drive_distance(-10); // New Code

  chassis.turn_to_angle(-135);
  chassis.drive_distance(20);
  chassis.turn_to_angle(10);
  Wings = true;
  chassis.drive_distance(5);  
  chassis.swing_timeout = 100;
  chassis.right_swing_to_angle(-45);
  chassis.drive_timeout = 1050;
  chassis.drive_distance(20); 
  
  Wings = false;
  Intake.spin(reverse);
  
  chassis.drive_timeout = 750;
  chassis.drive_distance(-22);
  Intake.stop(); 
  chassis.turn_to_angle(45);
  chassis.drive_distance(40);
  chassis.swing_timeout = 850;
  Wings = true;
  chassis.right_swing_to_angle(-105);
  chassis.drive_distance(8);
  chassis.swing_timeout = 100;
  chassis.left_swing_to_angle(-45);
  chassis.drive_timeout = 1050;
  chassis.drive_distance(15);
  Wings = false;
  chassis.turn_to_angle(-10);
  chassis.drive_distance(-20);
  chassis.turn_to_angle(-45);
  Wings = true;
  chassis.drive_timeout = 750;
  chassis.drive_distance(40);
  Wings = false;
  chassis.drive_distance(-20);

  chassis.turn_to_angle(10);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-15);
  chassis.turn_to_angle(45);
  VertRight = true;
  chassis.drive_distance(-25);
  VertRight = false;
  chassis.drive_distance(5);

  //chassis.turn_to_angle(45);
  //chassis.drive_distance(17);

  /*chassis.turn_to_angle(0);
  Wings = true;
  chassis.drive_distance(40);
  Intake.stop();
  Wings = false;
  chassis.turn_to_angle(-90);
  chassis.drive_distance(-18);
  chassis.turn_to_angle(45);  
  leftDrive.spin(fwd, -12, volt);
  rightDrive.spin(fwd, -12, volt);
  wait(1, sec);
  chassis.drive_distance(10);*/

  

  /*chassis.left_swing_to_angle(0); //Subbed Out
  Wings = true;
  chassis.left_swing_to_angle(20);
  chassis.drive_distance(18);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-15);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);*/

  /*Wings = false;           //Swing Test after crossing barrier for Programming Skills
  chassis.swing_timeout = 100;
  chassis.left_swing_to_angle(0);
  chassis.drive_distance(-30);
  Wings = true;
  chassis.drive_distance(15);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-15);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);*/



  
  /*Wings = true;              // Old Code
  Intake.stop();
  chassis.turn_to_angle(-45);
  chassis.drive_distance(30);
  Wings = false;
  chassis.drive_distance(-15);
  Wings = true;
  chassis.drive_distance(30);
  Wings = false;
  chassis.drive_distance(-15);
  chassis.turn_timeout = 1000;
  chassis.turn_to_angle(-135);
  chassis.drive_distance(15);
  chassis.swing_timeout = 1500;
  chassis.left_swing_to_angle(0);
  Wings = true;
  chassis.drive_distance(16);
  chassis.swing_timeout = 1500;
  chassis.right_swing_to_angle(-45);
  chassis.drive_timeout = 100;
  chassis.drive_distance(-5);
  chassis.drive_distance(20);
  Wings = false;
  chassis.drive_distance(-10);*/

  //Wings = false;
  //chassis.drive_distance(-38);
  //chassis.turn_to_angle(-45);
  
  /*chassis.turn_to_angle(-80);
  Wings = true;
  chassis.drive_distance(30);
  chassis.drive_distance(-2);
  Wings = false;
  chassis.drive_distance(-25);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(20);
  chassis.turn_to_angle(-45);
  Wings = true;
  chassis.drive_distance(35);
  chassis.drive_distance(-2);
  Wings = false;
  chassis.drive_distance(-25);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(25);
  chassis.turn_to_angle(0);
  Wings = true;
  chassis.drive_distance(35);
  Wings = false;
  chassis.drive_distance(-25);*/


}

void ProgSkillsUnder() {
  Lift.setVelocity(100, percent);
  Puncher.setVelocity(95, percent);
  Lift.setStopping(hold);
  Puncher.setStopping(hold);
  Intake.setVelocity(90, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);

  chassis.drive_distance(-15); 
  chassis.turn_to_angle(-60);
  Rachet = true;
  chassis.drive_distance(-1);
  VertRight = true;
  Puncher.spin(forward);
  Lift.spinFor(forward, 480, degrees);
  wait(33, seconds);
  VertRight = false;
  Lift.spinFor(reverse, 480, degrees);
  Puncher.stop();
  chassis.turn_to_angle(45);
  chassis.drive_distance(-11);
  chassis.drive_distance(12);
  chassis.turn_to_angle(0);
  chassis.drive_distance(18);
  chassis.turn_to_angle(-45);
  Puncher.setVelocity(40, percent);
  Puncher.spin(forward);
  waitUntil(Limit.pressing());
  Puncher.stop();
  Intake.spin(reverse);
  leftDrive.setVelocity(50, percent);
  rightDrive.setVelocity(50, percent);
 
 //Goes under the bar
  chassis.drive_distance(30);
  chassis.drive_distance(-10);
  chassis.drive_distance(55);

  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  /*chassis.turn_to_angle(-90);
  chassis.drive_distance(18);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(12);
  chassis.drive_distance(-14);
  Intake.stop();*/
  chassis.turn_to_angle(-200);
  chassis.drive_distance(30);
  Wings = true;
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(16);
  Wings = false;
  chassis.drive_distance(-16);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(26);
  chassis.right_swing_to_angle(-45);
  Wings = true;
  chassis.drive_distance(40);
  chassis.drive_distance(-40);
  chassis.drive_distance(40);
  chassis.drive_distance(-40);
  Wings = false;

  chassis.turn_to_angle(-135);
  chassis.drive_distance(15);
  chassis.left_swing_to_angle(5);
  Wings = true;
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(-45);
  chassis.drive_distance(-5);
  chassis.drive_distance(20);
  Wings = false;
  chassis.drive_distance(-20);




  
}

void FiveBall() {
  Intake.setVelocity(80, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);

  //Intake.spin(reverse);
  chassis.drive_distance(9);
  VertRight = true;
  //chassis.drive_distance(11);
  //wait(0.2, seconds);
  chassis.turn_to_angle(-50);
  VertRight = false;
  chassis.turn_timeout = 1000;
  chassis.turn_to_angle(-34);
  Intake.spin(reverse);
  Wings = true;
  chassis.drive_distance(16);
  Wings = false;
  Intake.stop();
  chassis.drive_distance(-13);
  chassis.turn_to_angle(-110);
  Intake.spin(forward);
  chassis.drive_distance(45);
  Intake.stop();
  chassis.turn_to_angle(20);
  chassis.drive_distance(16);
  Intake.setVelocity(100, percent);
  Intake.spinFor(reverse, 720, degrees);
  chassis.drive_distance(-2);

  chassis.turn_to_angle(-95);
  Intake.setVelocity(80, pct);
  Intake.spin(fwd);
  chassis.drive_distance(19.5);
  Intake.stop();
  chassis.turn_to_angle(45);
  Wings = true;
  Intake.spin(reverse);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(0.85, sec);
  Wings = false;
  chassis.drive_distance(-30);

  
}

void NearSideElims() {
  Intake.setVelocity(100, percent);

  VertRight = true; 
  chassis.turn_timeout = 750;
  Intake.spin(reverse);
  chassis.turn_to_angle(-85); // Descores Auton Triball
  chassis.turn_to_angle(-45); // Outtake Alliance triball in Intake
  VertRight = false;
  chassis.turn_to_angle(-90);
  Intake.stop();
  chassis.drive_distance(30); // Drives to the center of the field
  chassis.swing_timeout = 750;
  chassis.right_swing_to_angle(-135); // Aligns with center triball
  Intake.spin(forward);
  chassis.drive_distance(17); // Intakes center triball
  wait(0.5, seconds);
  chassis.drive_distance(-8);
  chassis.turn_to_angle(-45);
  Wings = true;
  Intake.spin(reverse);
  chassis.drive_timeout = 900;
  chassis.drive_distance(18); // Pushes the 2nd + 3rd Triball
  Wings = false;
  chassis.drive_distance(-25);
  Intake.stop();
  chassis.turn_to_angle(45);
  chassis.drive_distance(24);
  chassis.turn_to_angle(90);
  chassis.drive_distance(9);
  chassis.swing_timeout = 1000;
  //Wings = true;
  chassis.right_swing_to_angle(-50);
  //Wings = false;
  Intake.spin(reverse);
  chassis.drive_distance(25);


}

void NearSideRushDescore() {
  Intake.setVelocity(90, pct);

  chassis.drive_distance(36);
  chassis.turn_to_angle(35);
  Intake.spin(fwd);
  chassis.drive_distance(9);
  wait(0.5, seconds);
  chassis.drive_distance(-2);
  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(90);
  chassis.drive_timeout = 500;
  chassis.drive_distance(-5);

  Wings = true;
  Intake.spin(reverse);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(32);
  Wings = false;
  chassis.drive_distance(-17);
  Intake.stop();

  chassis.turn_to_angle(200);
  chassis.drive_distance(32);
  chassis.turn_to_angle(255);
  //chassis.drive_distance(3);
  chassis.right_swing_to_angle(135);
  chassis.drive_distance(-4);
  VertRight = true;
  chassis.drive_distance(8);
  chassis.turn_to_angle(90);
  VertRight = false;
  chassis.turn_to_angle(135);
  chassis.drive_distance(5);
  chassis.right_swing_to_angle(90);
  Intake.spin(reverse);
  chassis.drive_distance(28);
}

void NearSideRush() {
  Intake.setVelocity(90, pct);

  chassis.drive_distance(36);
  chassis.turn_to_angle(35);
  Intake.spin(fwd);
  chassis.drive_distance(9);
  wait(0.5, seconds);
  chassis.drive_distance(-2);
  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(90);
  chassis.drive_timeout = 500;
  chassis.drive_distance(-7);

  Wings = true;
  Intake.spin(reverse);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(32);
  Wings = false;
  chassis.drive_distance(-17);
  Intake.stop();

  chassis.turn_to_angle(200);
  chassis.drive_distance(32);
  chassis.turn_to_angle(255);
  //chassis.drive_distance(3);
  /*chassis.drive_distance(-4);
  VertRight = true;
  chassis.drive_distance(8);
  chassis.turn_to_angle(90);
  VertRight = false;
  chassis.turn_to_angle(135);
  chassis.drive_distance(5);*/
  chassis.right_swing_to_angle(90);
  Intake.spin(reverse);
  chassis.drive_distance(30);
}

void ProgSkillsNew_Over() {
  Intake.setVelocity(100, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  Lift.setVelocity(100, percent);
  Puncher.setVelocity(67, percent);
  Lift.setStopping(hold);
  Puncher.setStopping(hold);

  chassis.turn_to_angle(10);
  chassis.drive_distance(-15); 
  chassis.turn_to_angle(-62);
  chassis.drive_distance(-3); // initially -1
  VertRight = true;
  Puncher.spin(forward);
  Lift.spin(forward);
  waitUntil(RotationalSensor.position(degrees) <= 330 );
  Lift.stop();
  wait(23.5, seconds); //change to 24.5 seconds
  VertRight = false;
  //Lift.spinFor(reverse, 250, degrees);
  Lift.spin(reverse);
  Puncher.stop();
  
  chassis.turn_timeout = 500;
  chassis.turn_to_angle(45);
  //VertLeft = true;
  //Lift.stop();
  chassis.drive_timeout = 775;
  chassis.drive_distance(-14);
  Lift.stop();
  chassis.drive_distance(12);
  //VertLeft = false;

  chassis.turn_to_angle(-70);
  chassis.drive_distance(25);
  
  chassis.swing_timeout = 850;
  chassis.right_swing_to_angle(-135);

  Intake.spin(reverse);
  Wings = true;
  chassis.drive_distance(40);
  //chassis.drive_distance(20); // Ba Ba Booey

  chassis.left_swing_to_angle(-45);

  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  Intake.spin(reverse);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(25); // Initial Push to push triballs over barrier
  chassis.drive_timeout = 850;
  chassis.drive_distance(-25);
  Intake.stop();
  
  Wings = false;
  
  leftDrive.spin(fwd, 12, volt); // New Code Test
  rightDrive.spin(fwd, 12, volt);
  wait(2.1, sec);

  chassis.drive_distance(-13);

  chassis.turn_to_angle(-135);
  chassis.drive_distance(20);
  
  chassis.turn_to_angle(190);
  VertLeft = true;
  VertRight = true;
  chassis.drive_distance(-20);
  VertRight = false;
  chassis.left_swing_to_angle(135);
  chassis.drive_distance(13);
  chassis.drive_timeout = 1250;
  chassis.drive_distance(-50);
  VertLeft = false;

  chassis.drive_distance(20);
  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(45); // Was 45
  chassis.drive_distance(20);
  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(-90);
  Wings = true;
  chassis.drive_distance(10);
  chassis.left_swing_to_angle(-45);
  chassis.drive_distance(-8);
  leftDrive.spin(fwd, 12, volt); // New Code Test
  rightDrive.spin(fwd, 12, volt);
  wait(1.2, sec);
  chassis.drive_distance(-17);
  Wings = false;
  //chassis.drive_distance(28);
  chassis.swing_timeout = 1000;
  chassis.left_swing_to_angle(135);
  Intake.spin(reverse);
  VertRight = true;
  //VertLeft = true;
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-50);
  VertRight = false;
  /*chassis.right_swing_to_angle(135);
  VertLeft = false;
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-45);
  VertRight = false;
  Intake.stop();*/
  
  chassis.drive_distance(14); // Was -17
  /*chassis.swing_timeout = 1000;
  chassis.left_swing_to_angle(135);
  VertRight = true;
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-50);
  VertRight = false;
  
  chassis.drive_distance(15);*/
  Intake.spin(reverse);
  Wings = true;
  chassis.right_swing_to_angle(0);
  chassis.drive_distance(36);
  //chassis.drive_distance(30);
  Wings = false;
  
  chassis.swing_timeout = 1000;
  chassis.left_swing_to_angle(135);
  VertRight = true;
  chassis.drive_distance(-13);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-18);
  chassis.turn_to_angle(45);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-25);
  chassis.drive_distance(15);
  Intake.stop();

  Lift.spin(forward);
  VertRight = false;
  chassis.turn_to_angle(90);
  chassis.drive_distance(23);
  chassis.turn_to_angle(135);
  chassis.drive_distance(45);
  chassis.drive_distance(8);
  Lift.stop();
  Rachet = false;
  Lift.spin(reverse);


}


void ProgSkillsNew_Under() {
  Intake.setVelocity(100, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  Lift.setVelocity(100, percent);
  Puncher.setVelocity(67, percent);
  Lift.setStopping(hold);
  Puncher.setStopping(hold);

  chassis.turn_to_angle(10);
  chassis.drive_distance(-15); 
  chassis.turn_to_angle(-65);
  chassis.drive_distance(-2); // initially -1
  VertRight = true;
  Puncher.spin(forward);
  Lift.spin(forward);
  waitUntil(RotationalSensor.position(degrees) <= 330 );
  Lift.stop();
  wait(23.5, seconds); //change to 24.5 seconds
  VertRight = false;
  //Lift.spinFor(reverse, 250, degrees);
  Lift.spin(reverse);
  Puncher.stop();
  chassis.turn_timeout = 500;
  chassis.turn_to_angle(45);
  VertLeft = true;
  //Lift.stop();
  
  chassis.drive_timeout = 775;
  chassis.drive_distance(-14);
  Lift.stop();
  chassis.drive_distance(12);
  VertLeft = false;

  Intake.spin(reverse);
  chassis.turn_to_angle(-65);
  chassis.drive_distance(45);
  chassis.drive_distance(6.5);

  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(-135);
  Intake.spin(reverse);
  Wings = true;
  //chassis.drive_timeout = 1500;
  //chassis.drive_distance(80);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  leftDrive.spin(fwd, 12, volt); // New Code Test
  rightDrive.spin(fwd, 12, volt);
  wait(1.15, sec);
  Wings = false;
  chassis.drive_distance(-10);
  Intake.stop();
  chassis.turn_to_angle(-180);
  chassis.drive_distance(39);
  
  chassis.drive_distance(15);
  chassis.left_swing_to_angle(-45);
  Intake.spin(reverse);
  Puncher.spinFor(forward, 100, degrees);
  chassis.drive_distance(42);//consider putting one second pause
  Intake.stop();
  chassis.drive_distance(45);//was 45, push alley triballs to match loading bar
  chassis.turn_to_angle(0); // Was 180
  //VertLeft = true; 
  chassis.drive_distance(25); // Was -20
  chassis.turn_to_angle(45); // Was -135
  Intake.spin(reverse);
  chassis.drive_timeout = 750;
  chassis.drive_distance(50); // Was -50
  //VertLeft = false;
  
  chassis.drive_distance(-15); // Was 15
  chassis.turn_to_angle(105);
  Intake.stop();
  chassis.drive_distance(20);
  chassis.drive_distance(20);
  chassis.turn_to_angle(200);
  VertLeft = true;
  VertRight = true;
  chassis.drive_distance(-20);
  VertRight = false;
  chassis.left_swing_to_angle(135);
  chassis.drive_distance(7);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-50);
  VertLeft = false;
  
  chassis.drive_distance(20);
  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(45);
  chassis.drive_distance(13);
  chassis.swing_timeout = 1000;
  chassis.right_swing_to_angle(-45);
  Intake.spin(reverse);
  Wings = true;
  chassis.drive_timeout = 1000;
  chassis.drive_distance(50);
  Wings = false;
  Intake.stop();
  
  chassis.drive_distance(-17);
  chassis.swing_timeout = 1000;
  chassis.left_swing_to_angle(135);
  VertRight = true;
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-50);
  VertRight = false;
  
  chassis.drive_distance(15);
  Intake.spin(reverse);
  Wings = true;
  chassis.right_swing_to_angle(0);
  chassis.drive_distance(28);
  Wings = false;
  
  chassis.swing_timeout = 1000;
  chassis.left_swing_to_angle(135);
  VertRight = true;
  chassis.drive_distance(-12);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-14);
  chassis.turn_to_angle(45);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(-25);
  chassis.drive_distance(15);
  Intake.stop();

  Lift.spin(forward);
  VertRight = false;
  chassis.turn_to_angle(90);
  chassis.drive_distance(25);
  chassis.turn_to_angle(135);
  chassis.drive_distance(45);
  Lift.stop();
  Rachet = false;
  Lift.spin(reverse);

  


}