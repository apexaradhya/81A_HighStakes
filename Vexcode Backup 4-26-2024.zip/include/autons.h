#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();

void drive_test();
void turn_test();
void swing_test();
void full_test();
void odom_test();
void tank_odom_test();
void holonomic_odom_test();
void NearSideQuals();
void SixBall();
void FourBall();
void ProgSkillsOver();
void FiveBall();
void ProgSkillsUnder();
void NearSideElims();
void NearSideRushDescore();
void NearSideRush();
void ProgSkillsNew_Over();
void ProgSkillsNew_Under();
void ProgSkillsOver_Newest();