using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor leftDriveA;
extern motor leftDriveB;
extern motor leftMotorC;
extern motor rightMotorA;
extern motor rightMotorB;
extern motor rightMotorC;
extern motor_group Intake;
extern motor Puncher;
extern inertial Inertial20;
extern digital_out Wings;
extern motor Lift;
extern controller Controller1;
extern digital_out VertRight;
extern limit Limit;
extern digital_out Rachet;
extern limit LimitSelector;
extern digital_out VertLeft;
extern rotation RotationalSensor;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );