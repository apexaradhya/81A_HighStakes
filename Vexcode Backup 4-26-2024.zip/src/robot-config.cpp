#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor leftDriveA = motor(PORT11, ratio6_1, true);
motor leftDriveB = motor(PORT14, ratio6_1, true);
motor leftMotorC = motor(PORT17, ratio18_1, true);
motor rightMotorA = motor(PORT12, ratio6_1, false);
motor rightMotorB = motor(PORT13, ratio6_1, false);
motor rightMotorC = motor(PORT15, ratio18_1, false);
motor IntakeMotorA = motor(PORT19, ratio18_1, false);
motor IntakeMotorB = motor(PORT10, ratio18_1, true);
motor_group Intake = motor_group(IntakeMotorA, IntakeMotorB);
motor Puncher = motor(PORT9, ratio36_1, false);
inertial Inertial20 = inertial(PORT20);
digital_out Wings = digital_out(Brain.ThreeWirePort.A);
motor Lift = motor(PORT2, ratio36_1, true);
controller Controller1 = controller(primary);
digital_out VertRight = digital_out(Brain.ThreeWirePort.B);
limit Limit = limit(Brain.ThreeWirePort.H);
digital_out Rachet = digital_out(Brain.ThreeWirePort.C);
limit LimitSelector = limit(Brain.ThreeWirePort.D);
digital_out VertLeft = digital_out(Brain.ThreeWirePort.E);
rotation RotationalSensor = rotation(PORT1, false);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}