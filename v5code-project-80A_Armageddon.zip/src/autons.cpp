#include "vex.h"

motor_group leftDrive = motor_group(leftDriveA, leftDriveB, leftMotorC);


motor_group rightDrive = motor_group(rightMotorA, rightMotorB, rightMotorC);

void default_constants(){
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);
  chassis.set_drive_exit_conditions(1.5, 300, 5000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

void odom_constants(){
  default_constants();
  chassis.drive_max_voltage = 8;
  chassis.drive_settle_error = 3;
}

void drive_test(){
  chassis.drive_distance(6);
  chassis.drive_distance(12);
  chassis.drive_distance(18);
  chassis.drive_distance(-36);
}

void turn_test(){
  chassis.turn_to_angle(5);
  chassis.turn_to_angle(30);
  chassis.turn_to_angle(90);
  chassis.turn_to_angle(225);
  chassis.turn_to_angle(0);
}

void swing_test(){
  chassis.left_swing_to_angle(90);
  chassis.right_swing_to_angle(0);
}

void full_test(){
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-36);
  chassis.right_swing_to_angle(-90);
  chassis.drive_distance(24);
  chassis.turn_to_angle(0);
}

void odom_test(){
  chassis.set_coordinates(0, 0, 0);
  while(1){
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(0,50, "X: %f", chassis.get_X_position());
    Brain.Screen.printAt(0,70, "Y: %f", chassis.get_Y_position());
    Brain.Screen.printAt(0,90, "Heading: %f", chassis.get_absolute_heading());
    Brain.Screen.printAt(0,110, "ForwardTracker: %f", chassis.get_ForwardTracker_position());
    Brain.Screen.printAt(0,130, "SidewaysTracker: %f", chassis.get_SidewaysTracker_position());
    task::sleep(20);
  }
}

void tank_odom_test(){
  odom_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.turn_to_point(24, 24);
  chassis.drive_to_point(24,24);
  chassis.drive_to_point(0,0);
  chassis.turn_to_angle(0);
}

void holonomic_odom_test(){
  odom_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.holonomic_drive_to_point(0, 18, 90);
  chassis.holonomic_drive_to_point(18, 0, 180);
  chassis.holonomic_drive_to_point(0, 18, 270);
  chassis.holonomic_drive_to_point(0, 0, 0);
}

void NearSideAuto() {
  Intake.setVelocity(100, percent);

  Dropdown = true;

  Intake.spin(reverse);
  chassis.turn_to_angle(-35);
  Intake.stop();

  Dropdown = false;
  chassis.turn_to_angle(-80);
  chassis.turn_to_angle(0);
  chassis.drive_distance(6);
  chassis.turn_to_angle(-45);
  Intake.spin(reverse);
  chassis.drive_distance(31);

}

void SixBall() {
  leftDrive.setVelocity(100, percent); // Sets Drive Velocity
  rightDrive.setVelocity(100, percent);

  Intake.setVelocity(100, percent); // Sets Intake Velocity

  Intake.spin(forward); // Intakes First Triball Under Elevation Bar
  chassis.drive_distance(3);

  Intake.stop();
  chassis.drive_distance(-33); // Drives reverse towards the goal

  chassis.turn_to_angle(-45); // Aligns itself with Matchload bar
  chassis.drive_distance(-16);

  chassis.turn_to_angle(-90);
  chassis.drive_distance(-3);
  chassis.turn_to_angle(108); // Turns so that intake is facing towards the goal

  Intake.spin(reverse); // Outtakes green Triball that was under bar
  chassis.drive_distance(14); // Pushes both Alliance triball and Triball that was under the bar
  chassis.drive_distance(-8); // Drives back

  chassis.turn_to_angle(14); // Turns to align is=tself with the left-most triball placed near the barrier
  Intake.spin(forward); // Intakes the Triball
  chassis.drive_distance(44);
  Intake.stop();

  chassis.turn_to_angle(135); // Turns to face the goal
  chassis.drive_distance(15);
  Intake.spinFor(reverse, 1000, degrees); // Outtakes the 3rd triball
  chassis.turn_to_angle(50); // Aligns with Center triball near the barrie
  Intake.spin(forward); // Intakes the Triball
  chassis.drive_distance(20);
  Intake.stop();
  chassis.turn_to_angle(180); // Faces the goal
  Wings = true; // Uses Wings to push the triballs in at once
  Intake.spin(reverse);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);



}


void FourBall() {

  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  Intake.setVelocity(100, percent);

  chassis.drive_distance(40);
  chassis.turn_to_angle(60);
  Intake.spinFor(reverse, 720, degrees);
  chassis.drive_distance(-2);
  Intake.stop();
  //Intake.setVelocity(100, percent);
  chassis.turn_to_angle(-115);
  Intake.spin(forward);
  chassis.drive_distance(22);
  wait(0.1, seconds);
  Intake.stop();
  chassis.turn_to_angle(60);
  //Intake.setVelocity(50, percent);
  chassis.drive_distance(10);
  Intake.spinFor(reverse, 360, degrees);
  chassis.turn_to_angle(-55);
  
  Intake.spin(forward);
  chassis.drive_distance(15);
  Intake.stop();
  chassis.turn_to_angle(70);

  Wings = true;

  Intake.spin(reverse);
  chassis.drive_distance(30);
  Wings = false;

}

void ProgSkillsOver() {
  Lift.setVelocity(100, percent);
  Puncher.setVelocity(100, percent);
  Lift.setStopping(hold);
  Puncher.setStopping(hold);
  Intake.setVelocity(90, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);

  
  chassis.drive_distance(-15); 
  chassis.turn_to_angle(-60);
  chassis.drive_distance(-1);
  Dropdown = true;
  Puncher.spin(forward);
  Lift.spinFor(forward, 480, degrees);
  wait(31.5, seconds);
  Dropdown = false;
  Lift.spinFor(reverse, 480, degrees);
  Puncher.stop();
  chassis.turn_timeout = 500;
  chassis.turn_to_angle(45);
  chassis.drive_distance(-12);
  chassis.drive_distance(13);
  //chassis.turn_timeout = 1000;
  chassis.turn_to_angle(-70);
  chassis.drive_distance(25);
  chassis.turn_to_angle(-130);
  //Wings = true;
  Intake.spin(reverse);
  chassis.drive_distance(30);
  //Wings = false;
  chassis.turn_to_angle(-45);
  //leftDrive.setVelocity(100, percent);
  //rightDrive.setVelocity(100, percent);
  //chassis.drive_distance(-5);
  //chassis.turn_to_angle(-135);
  //Intake.stop();
  //chassis.drive_distance(20);
  //chassis.drive_distance(-5);
  //chassis.turn_to_angle(-45);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  Intake.spin(reverse);
  chassis.drive_timeout = 1000;
  chassis.drive_distance(22); // Initial Push to push triballs over barrier
  chassis.drive_timeout = 850;
  chassis.drive_distance(-15);
  Intake.stop();

  Wings = true;
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1.5, sec);
  Wings = false;
  chassis.turn_to_angle(-135);
  chassis.drive_distance(25);
  chassis.turn_to_angle(10);
  Wings = true;
  chassis.drive_distance(5);  
  chassis.swing_timeout = 100;
  chassis.right_swing_to_angle(-45);
  chassis.drive_timeout = 1050;
  chassis.drive_distance(20); 
  
  Wings = false;
  Intake.spin(reverse);
  
  chassis.drive_timeout = 750;
  chassis.drive_distance(-22);
  Intake.stop(); 
  chassis.turn_to_angle(45);
  chassis.drive_distance(45);
  chassis.swing_timeout = 850;
  Wings = true;
  chassis.right_swing_to_angle(-105);
  chassis.drive_distance(8);
  chassis.swing_timeout = 100;
  chassis.left_swing_to_angle(-45);
  chassis.drive_timeout = 1050;
  chassis.drive_distance(15);
  Wings = false;
  chassis.turn_to_angle(-10);
  chassis.drive_distance(-20);
  chassis.turn_to_angle(-45);
  Wings = true;
  chassis.drive_timeout = 750;
  chassis.drive_distance(45);
  Wings = false;
  chassis.drive_distance(-25);

  chassis.turn_to_angle(0);
  chassis.drive_distance(70);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(45);
  Dropdown = true;
  chassis.drive_distance(-25);
  Dropdown = false;
  chassis.drive_distance(5);

  //chassis.turn_to_angle(45);
  //chassis.drive_distance(17);

  /*chassis.turn_to_angle(0);
  Wings = true;
  chassis.drive_distance(40);
  Intake.stop();
  Wings = false;
  chassis.turn_to_angle(-90);
  chassis.drive_distance(-18);
  chassis.turn_to_angle(45);  
  leftDrive.spin(fwd, -12, volt);
  rightDrive.spin(fwd, -12, volt);
  wait(1, sec);
  chassis.drive_distance(10);*/

  

  /*chassis.left_swing_to_angle(0); //Subbed Out
  Wings = true;
  chassis.left_swing_to_angle(20);
  chassis.drive_distance(18);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-15);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);*/

  /*Wings = false;           //Swing Test after crossing barrier for Programming Skills
  chassis.swing_timeout = 100;
  chassis.left_swing_to_angle(0);
  chassis.drive_distance(-30);
  Wings = true;
  chassis.drive_distance(15);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-15);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(1, sec);*/



  
  /*Wings = true;              // Old Code
  Intake.stop();
  chassis.turn_to_angle(-45);
  chassis.drive_distance(30);
  Wings = false;
  chassis.drive_distance(-15);
  Wings = true;
  chassis.drive_distance(30);
  Wings = false;
  chassis.drive_distance(-15);
  chassis.turn_timeout = 1000;
  chassis.turn_to_angle(-135);
  chassis.drive_distance(15);
  chassis.swing_timeout = 1500;
  chassis.left_swing_to_angle(0);
  Wings = true;
  chassis.drive_distance(16);
  chassis.swing_timeout = 1500;
  chassis.right_swing_to_angle(-45);
  chassis.drive_timeout = 100;
  chassis.drive_distance(-5);
  chassis.drive_distance(20);
  Wings = false;
  chassis.drive_distance(-10);*/

  //Wings = false;
  //chassis.drive_distance(-38);
  //chassis.turn_to_angle(-45);
  
  /*chassis.turn_to_angle(-80);
  Wings = true;
  chassis.drive_distance(30);
  chassis.drive_distance(-2);
  Wings = false;
  chassis.drive_distance(-25);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(20);
  chassis.turn_to_angle(-45);
  Wings = true;
  chassis.drive_distance(35);
  chassis.drive_distance(-2);
  Wings = false;
  chassis.drive_distance(-25);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(25);
  chassis.turn_to_angle(0);
  Wings = true;
  chassis.drive_distance(35);
  Wings = false;
  chassis.drive_distance(-25);*/


}

void ProgSkillsUnder() {
  Lift.setVelocity(100, percent);
  Puncher.setVelocity(95, percent);
  Lift.setStopping(hold);
  Puncher.setStopping(hold);
  Intake.setVelocity(90, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);

  chassis.drive_distance(-15); 
  chassis.turn_to_angle(-60);
  Rachet = true;
  chassis.drive_distance(-1);
  Dropdown = true;
  Puncher.spin(forward);
  Lift.spinFor(forward, 480, degrees);
  wait(33, seconds);
  Dropdown = false;
  Lift.spinFor(reverse, 480, degrees);
  Puncher.stop();
  chassis.turn_to_angle(45);
  chassis.drive_distance(-11);
  chassis.drive_distance(12);
  chassis.turn_to_angle(0);
  chassis.drive_distance(18);
  chassis.turn_to_angle(-45);
  Puncher.setVelocity(40, percent);
  Puncher.spin(forward);
  waitUntil(Limit.pressing());
  Puncher.stop();
  Intake.spin(reverse);
  leftDrive.setVelocity(50, percent);
  rightDrive.setVelocity(50, percent);
 
 //Goes under the bar
  chassis.drive_distance(30);
  chassis.drive_distance(-10);
  chassis.drive_distance(55);

  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);
  
  /*chassis.turn_to_angle(-90);
  chassis.drive_distance(18);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(12);
  chassis.drive_distance(-14);
  Intake.stop();*/
  chassis.turn_to_angle(-200);
  chassis.drive_distance(30);
  Wings = true;
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(16);
  Wings = false;
  chassis.drive_distance(-16);
  chassis.turn_to_angle(-135);
  chassis.drive_distance(26);
  chassis.right_swing_to_angle(-45);
  Wings = true;
  chassis.drive_distance(40);
  chassis.drive_distance(-40);
  chassis.drive_distance(40);
  chassis.drive_distance(-40);
  Wings = false;

  chassis.turn_to_angle(-135);
  chassis.drive_distance(15);
  chassis.left_swing_to_angle(5);
  Wings = true;
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(-45);
  chassis.drive_distance(-5);
  chassis.drive_distance(20);
  Wings = false;
  chassis.drive_distance(-20);




  
}

void FiveBall() {
  Intake.setVelocity(80, percent);
  leftDrive.setVelocity(100, percent);
  rightDrive.setVelocity(100, percent);

  //Intake.spin(reverse);
  chassis.drive_distance(9);
  Dropdown = true;
  //chassis.drive_distance(11);
  //wait(0.2, seconds);
  chassis.turn_to_angle(-50);
  Dropdown = false;
  chassis.turn_timeout = 1000;
  chassis.turn_to_angle(-34);
  Intake.spin(reverse);
  Wings = true;
  chassis.drive_distance(16);
  Wings = false;
  Intake.stop();
  chassis.drive_distance(-10);
  chassis.turn_to_angle(-110);
  Intake.spin(forward);
  chassis.drive_distance(45);
  Intake.stop();
  chassis.turn_to_angle(20);
  chassis.drive_distance(16);
  Intake.setVelocity(100, percent);
  Intake.spinFor(reverse, 720, degrees);
  chassis.drive_distance(-2);

  chassis.turn_to_angle(-95);
  Intake.setVelocity(80, pct);
  Intake.spin(fwd);
  chassis.drive_distance(19.5);
  Intake.stop();
  chassis.turn_to_angle(45);
  Wings = true;
  Intake.spin(reverse);
  leftDrive.spin(fwd, 12, volt);
  rightDrive.spin(fwd, 12, volt);
  wait(0.85, sec);
  Wings = false;
  chassis.drive_distance(-30);

  
}

void NearSideElims() {
  Intake.setVelocity(100, percent);

  chassis.drive_distance(40);
  chassis.turn_to_angle(-40);
  Intake.spinFor(reverse, 1000, degrees);
  chassis.turn_to_angle(40);
  Intake.spin(forward);
  chassis.drive_distance(7);
  wait(0.35, seconds);
  chassis.drive_distance(-10);
  chassis.swing_timeout = 1500;
  chassis.right_swing_to_angle(90);
  Wings = true;
  chassis.drive_distance(40);
  Intake.spin(reverse);
  chassis.drive_distance(-10);
  Intake.stop();
  Wings = false;

}