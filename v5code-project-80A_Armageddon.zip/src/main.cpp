#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// leftDriveA           motor         11              
// leftDriveB           motor         14              
// leftMotorC           motor         17              
// rightMotorA          motor         12              
// rightMotorB          motor         13              
// rightMotorC          motor         15              
// Intake               motor_group   19, 10          
// Puncher              motor         9               
// Inertial20           inertial      20              
// Wings                digital_out   A               
// Lift                 motor         2               
// Controller1          controller                    
// Dropdown             digital_out   B               
// Limit                limit         H               
// Rachet               digital_out   C               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;
competition Competition;

/*---------------------------------------------------------------------------*/
/*                             VEXcode Config                                */
/*                                                                           */
/*  Before you do anything else, start by configuring your motors and        */
/*  sensors using the V5 port icon in the top right of the screen. Doing     */
/*  so will update robot-config.cpp and robot-config.h automatically, so     */
/*  you don't have to. Ensure that your motors are reversed properly. For    */
/*  the drive, spinning all motors forward should drive the robot forward.   */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/*                             JAR-Template Config                           */
/*                                                                           */
/*  Where all the magic happens. Follow the instructions below to input      */
/*  all the physical constants and values for your robot. You should         */
/*  already have configured your robot manually with the sidebar configurer. */
/*---------------------------------------------------------------------------*/

Drive chassis(

//Specify your drive setup below. There are seven options:
//ZERO_TRACKER_NO_ODOM, ZERO_TRACKER_ODOM, TANK_ONE_ENCODER, TANK_ONE_ROTATION, TANK_TWO_ENCODER, TANK_TWO_ROTATION, HOLONOMIC_TWO_ENCODER, and HOLONOMIC_TWO_ROTATION
//For example, if you are not using odometry, put ZERO_TRACKER_NO_ODOM below:
ZERO_TRACKER_NO_ODOM,

//Add the names of your Drive motors into the motor groups below, separated by commas, i.e. motor_group(Motor1,Motor2,Motor3).
//You will input whatever motor names you chose when you configured your robot using the sidebar configurer, they don't have to be "Motor1" and "Motor2".

//Left Motors:
motor_group(leftDriveA, leftDriveB, leftMotorC),

//Right Motors:
motor_group(rightMotorA, rightMotorB, rightMotorC),

//Specify the PORT NUMBER of your inertial sensor, in PORT format (i.e. "PORT1", not simply "1"):
PORT20,

//Input your wheel diameter. (4" omnis are actually closer to 4.125"):
3.25,

//External ratio, must be in decimal, in the format of input teeth/output teeth.
//If your motor has an 84-tooth gear and your wheel has a 60-tooth gear, this value will be 1.4.
//If the motor drives the wheel directly, this value is 1:
0.6,

//Gyro scale, this is what your gyro reads when you spin the robot 360 degrees.
//For most cases 360 will do fine here, but this scale factor can be very helpful when precision is necessary.
360,

/*---------------------------------------------------------------------------*/
/*                                  PAUSE!                                   */
/*                                                                           */
/*  The rest of the drive constructor is for robots using POSITION TRACKING. */
/*  If you are not using position tracking, leave the rest of the values as  */
/*  they are.                                                                */
/*---------------------------------------------------------------------------*/

//If you are using ZERO_TRACKER_ODOM, you ONLY need to adjust the FORWARD TRACKER CENTER DISTANCE.

//FOR HOLONOMIC DRIVES ONLY: Input your drive motors by position. This is only necessary for holonomic drives, otherwise this section can be left alone.
//LF:      //RF:    
PORT1,     -PORT2,

//LB:      //RB: 
PORT3,     -PORT4,

//If you are using position tracking, this is the Forward Tracker port (the tracker which runs parallel to the direction of the chassis).
//If this is a rotation sensor, enter it in "PORT1" format, inputting the port below.
//If this is an encoder, enter the port as an integer. Triport A will be a "1", Triport B will be a "2", etc.
3,

//Input the Forward Tracker diameter (reverse it to make the direction switch):
2.75,

//Input Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
//For a zero tracker tank drive with odom, put the positive distance from the center of the robot to the right side of the drive.
//This distance is in inches:
-2,

//Input the Sideways Tracker Port, following the same steps as the Forward Tracker Port:
1,

//Sideways tracker diameter (reverse to make the direction switch):
-2.75,

//Sideways tracker center distance (positive distance is behind the center of the robot, negative is in front):
5.5

);

int current_auton_selection = 0;
bool auto_started = false;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  default_constants();

  Inertial20.calibrate();
  wait(2, seconds);
  
  Rachet = true;


  while(auto_started == false){            //Changing the names below will only change their names on the
    Brain.Screen.clearScreen();            //brain screen for auton selection.
    switch(current_auton_selection){       //Tap the brain screen to cycle through autons.
      case 0:
        Brain.Screen.printAt(50, 50, "Five Ball Autonomous");
        break;
      case 1:
        Brain.Screen.printAt(50, 50, "Near Side Autonomous - Qualifications");
        break;
      case 2:
        Brain.Screen.printAt(50, 50, "Programming Skills - Under Barrier");
        break;
      case 3:
        Brain.Screen.printAt(50, 50, "Near Side Autonomous - Eliminations");
        break;
      case 4:
        Brain.Screen.printAt(50, 50, "Programming Skills - Over Barrier");
        break;
      case 5:
        Brain.Screen.printAt(50, 50, "Four Ball Autonomous");
        break;
      case 6:
        Brain.Screen.printAt(50, 50, "Six Ball Autonomous");
        break;
      case 7:
        Brain.Screen.printAt(50, 50, "Holonomic Odom Test");
        break;
      case 8:
        Brain.Screen.printAt(50, 50, "drive Test");
        break;
      case 9:
        Brain.Screen.printAt(50, 50, "Drive Test");
        break;
    }
    if(Brain.Screen.pressing()){
      while(Brain.Screen.pressing()) {}
      current_auton_selection ++;
    } else if (current_auton_selection == 10){
      current_auton_selection = 0;
    }
    task::sleep(10);
  }
}



void autonomous(void) {
  auto_started = true;



  switch(current_auton_selection){  
    case 0:
      FiveBall(); //This is the default auton, if you don't select from the brain.
      break;        //Change these to be your own auton functions in order to use the auton selector.
    case 1:         //Tap the screen to cycle through autons.
      NearSideAuto();
      break;
    case 2:
      ProgSkillsUnder();
    case 3:
      NearSideElims();
      break;
    case 4:
      ProgSkillsOver();
      break;
    case 5:
      FourBall();
      break;
    case 6:
      SixBall();
      break;
    case 7:
      holonomic_odom_test();
      break;
    case 8:
      drive_test();
      break;
    case 9:
      drive_test();
      break;
 }
}

bool toggle = false;

bool latch = false;

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
void usercontrol(void) {
  // User control code here, inside the loop
  Puncher.setBrake(hold);
  Puncher.setVelocity(100, percent);
  Lift.setVelocity(100, percent);
  Intake.setVelocity(100, percent);
  Lift.setBrake(hold);
  
    Controller1.Screen.print(leftDriveA.temperature());
    Controller1.Screen.print(leftDriveB.temperature());
    Controller1.Screen.print(leftMotorC.temperature());
    Controller1.Screen.print(rightMotorA.temperature());
    Controller1.Screen.print(rightMotorB.temperature());
    Controller1.Screen.print(rightMotorC.temperature());

  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................
    
    if (Controller1.ButtonL1.pressing()) {
      Intake.spin(forward);
    }
    else if (Controller1.ButtonL2.pressing()) {
      Intake.spin(reverse);
    }
    else {
      Intake.stop();
    }
    
    if (Controller1.ButtonR1.pressing()) {
      Lift.spin(forward);
    }
    else if (Controller1.ButtonR2.pressing()) {
      Lift.spin(reverse);
    }
    else {
      Lift.stop();
    }

    if(Controller1.ButtonUp.pressing()) {
      Puncher.spin(forward);
    }
    else {
      Puncher.stop();
    }
    if(Controller1.ButtonY.pressing()) {
      Wings = true;
    }
    if(Controller1.ButtonB.pressing()) {
      Wings = false;
    }
    if(Controller1.ButtonRight.pressing()) {
      Dropdown = true;
    }
    if(Controller1.ButtonDown.pressing()) {
      Dropdown = false;
      
    }
    if(Controller1.ButtonA.pressing()) {
      Rachet = true; // Rachet Disengaged
    }
    if(Controller1.ButtonX.pressing()) {
      Rachet = false; // Rachet Engaged
    }
    
    if (toggle){
      Puncher.spin(forward);
    }
    else {
      Puncher.stop();
    }
    if (Controller1.ButtonUp.pressing()) {
      if(!latch){ //flip the toggle one time and set the latch
      toggle = !toggle;
      latch = true;
      }
    } else {
      //Once the BumperA is released then then release the latch too
      latch = false;
    }
    if (Controller1.ButtonLeft.pressing()) {
      if (Limit.pressing()) {
      Puncher.stop();
      }
      else {
      Puncher.spin(forward);
      }
    }


    //Replace this line with chassis.control_tank(); for tank drive 
    //or chassis.control_holonomic(); for holo drive.
    chassis.control_tank();
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.

    //Brain.Screen.print(leftDriveA.temperature(), ",", leftDriveB.temperature(), ",", leftMotorC.temperature(), ",", rightMotorA.temperature(), ",", rightMotorB.temperature(), ",", rightMotorC.temperature());
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
